import { Component } from '@angular/core';

@Component({
  selector: 'app-homealt',
  templateUrl: './homealt.component.html',
  styleUrls: ['./homealt.component.css']
})
export class HomealtComponent {

}
