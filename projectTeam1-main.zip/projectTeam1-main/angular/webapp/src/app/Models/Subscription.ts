export class Subscription{
    id?:string;
    userId?: string;
    type?:number;
    startDate?:Date;
    endDate?:Date;
    status?:number;
    createdAt?:Date;
    updatedAt?:Date;
}