export class MenuItem{
  menuItemId?: string;
  name?: string;
  price?: number;
  description?: string;
  category?: string;
  image?: any;
}