import { Address } from './Address';

export class User
{
    userEmailId?:string;
    name?:string;
    password?:string;
    mobileNo?:number;
    userImage?:string;
    address?:Address;
}