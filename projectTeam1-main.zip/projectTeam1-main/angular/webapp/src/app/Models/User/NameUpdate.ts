export class NameUpdate
{
    userEmailId?:string;
    name?:string;
}