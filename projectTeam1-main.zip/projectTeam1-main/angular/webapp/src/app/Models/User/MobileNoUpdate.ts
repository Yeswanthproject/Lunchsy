export class MobileNoUpdate
{
    userEmailId?:string;
    mobileNo?:number;
}