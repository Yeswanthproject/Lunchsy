export class Address
{
    AddressId?:number;
    houseNo?:string;
    landmark?:string;
    city?:string;
    state?:string;
    country?:string;
    pincode?:number;
    userEmailId?:string;
}