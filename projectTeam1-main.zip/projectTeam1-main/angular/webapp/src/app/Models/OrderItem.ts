export class OrderItem{
  menuItemId?: string;
  quantity?: number;
  name?: string;
}