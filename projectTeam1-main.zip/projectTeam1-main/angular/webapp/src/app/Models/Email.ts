export class Email{
  emailId?: string;
  subject?: string;
  body?: string;
}