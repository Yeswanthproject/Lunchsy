﻿namespace UserService.Models
{
    public class AddressUpdateData
    {
        public string UserEmailId { get; set; }
        public Address Address { get; set; }
    }
}
