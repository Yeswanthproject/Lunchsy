﻿namespace MenuService.DataModel
{
    public class FileModel
    {
        public string MenuItemId { get; set; }
        public IFormFile FormFile { get; set; }

    }
}
