﻿namespace MenuService.Exceptions
{
    public class MenuAlreadyExistException:Exception
    {
        public MenuAlreadyExistException()
        {
            
        }
        public MenuAlreadyExistException(string message):base(message)
        {
        
        
        }
       
    }
}
