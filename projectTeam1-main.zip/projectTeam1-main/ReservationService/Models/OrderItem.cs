﻿namespace OrderService.Models
{
    
        public class OrderItem
        {  // public int id { get; set; }

            public string MenuItemId { get; set; }
            public int Quantity { get; set; }
            public string Name { get; set; }
        }

    

    
}
