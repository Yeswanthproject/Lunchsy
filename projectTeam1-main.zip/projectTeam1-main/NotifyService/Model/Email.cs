﻿namespace NotifyService.Model
{
    public class Email
    {
        public string emailId { get; set; }
        public string subject { get; set; }
        public string body { get; set; }

    }
}
